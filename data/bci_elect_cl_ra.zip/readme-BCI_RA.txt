Electronic Precipitation is currently measured using Hydrological Services Model TB3 tipping buckets.

File Structure:
Datetime (yyyy-mm-dd HH:MM), Raw Values (mm), Curated Values (mm), Notes1, Notes2

Notes1 and Notes2 provide Quality Assurance information. 

Notes1 indicates quality of record. Possible values are:
	"adjusted"		-> Value of datum adjusted or gap filled
	"bad"			-> Datum failed one or more test and should not be used
	"doubtful"		-> Datum suspect and should be used with caution
	"good"			-> Datum accetible
	"missing"		-> Datum missing
	"nc"	  	    -> Datum not yet checked

Notes2 indicates the reason that a datum failed or was adjusted. Possible values are:
	"Calibration"	-> Sensor calibration corrected
	"Persistence"	-> Variation of data below expected range
	"Range"			-> Datum outside of 99.9 percentile
	"Spike"			-> Short-term increase or decrease of data significantly outside normal variance range
	"Gap Fill"		-> Data supplied from another source
	

Quality Assurance Proceedures:
	- Data are loaded into a custom-built program which premits easy visual examination of the data (including simultaneous viewing of rainfall data)
	- Data are visually examined for anomalies and are flagged, and adjusted when necessary, as required.
	
Data Files:
	Tipping Bucket data:
		bci_cl_ra_elect.csv:  	Contains all records for the entire period
		bci_cl_ra_elect2.csv: 	Contains only records with rainfall
	OTT Pluvio2 S sensor
		bci_cl_ra2_int_elect:	Real-time output: the measurement results greater than 0.1mm/min within one minute after the occurrence of the precipitation event (fastest response)
		bci_cl_ra2_nrt_elect	Non-real-time output: the measurement results 5 minutes after occurrence of the precipitation event (more accurate) 
		bci_cl_ra2_comb_elect:	Currently measured, unfiltered bucket content
		bci_cl_ra2_cum_elect:	Currently measured, filtered bucket content